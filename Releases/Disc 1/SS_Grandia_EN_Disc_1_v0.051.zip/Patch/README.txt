
		Sega Saturn Grandia
		   English Patch
		  April 4th, 2019	


This Patch will apply the official English Translation from
the Sony Playstation version of Grandia to the original
Japanese Sega Saturn release. 

To follow the progress of this hack please be sure to pay
attention to the thread at SegaXtreme.net:

https://segaxtreme.net/threads/translating-grandia.24330/

----------------------------------------------------------
 C O N T E N T S
----------------------------------------------------------

1. Source Image and Checksum Info
2. How to apply the patch
3. Known Issues
4. Change Log

----------------------------------------------------------
1. Source Image and Checksum Info
----------------------------------------------------------

The Image used for this was a rip from my personal copy of
 the game. There's little information out there if there
are other revisions of the game so be sure to check the
checksums. I ripped my image file using ImgBurn and ripped
as BIN/CUE format. After which I extracted the Data Track
into an ISO file.

The Checksums Pre-Patch should be as follows for the ISO file:

MD5:     D1C273B9871A34E5D7A7168E30CDB421
CRC-32:  D4BF88BE
SHA-1 :  75146114330BA9A028974253FB2186A29241D631
SHA-256: 68FA1AED046E4F4F052E67A0A4FD56D4E3C661BF77A478854D96D9AD772CE543

Post Patch Checksums should be this:
 
MD5:     4D6F460B2053AB27B5C7E66614C26D08
CRC-32:  2245501F
SHA-1 :  8C724A127D496A86EC9F1DE77DC81941E0702A8C
SHA-256: 3E5B22C78D8BAB2B810B3FD463D679567375DC0775DEBBA59F004BE86644FC31

----------------------------------------------------------
2. How to apply the patch
----------------------------------------------------------

First you'll need a BIN/CUE rip of the game. I suggest using
ImgBurn to rip your personal disc in BIN/CUE format at the
Slowest possible speed.

You will then need to extract the data track from the BIN file. 
This will give you an ISO file that you can apply the patch to.
To do this you'll need additional software. The Software I used
was IsoBuster which can be found here:

https://www.isobuster.com/download.php

After installing and starting up IsoBuster, open the BIN/CUE image
you created of your Grandia disc with it:

	1) Go to File > Open Image File
	2) Select the CUE file of your Grandia rip
	3) Click Open.

Next you'll need to extract the seprate tracks:

	1) Right click on Session 1
	2) Select Extract Session 1 > Extract User Data

This will open a prompt asking where you want to save the data.
Navigate to the directory of your choosing and click OK.

This will give you Track 01 as an ISO and Track 02 as a Wav file.
Rename these as follows:

	- GRANDIA.iso
	- GRANDIA.wav

You are now ready to apply the patch. The patch is in xdelta format,
so you'll neeed to use a patching utility. I'd recommend using 
DeltaPatcher or DeltaPatcher Lite. Using DeltaPatcher apply the
the patch as follows:

	1) Select GRANDIA.iso as your original file.
	2) Select the patch file included in this zip as the patch
	3) Click Appy Patch.

If that all went well you should be ready to go. The included CUE
sheet is designed to be used with the extracted GRANDIA.wav file
that IsoBuster extracted. If this does not work or you extracted
the files under different names, you can use the SegaCueMaker to 
generate a new one.


----------------------------------------------------------
3. Known Issues
----------------------------------------------------------

This is still a very early release, so it is advised that 
you play this in an emulator as crashes are likely to occur.
The preferred Emulator is Mednafen as it seems to behave the
closest to the real deal. If Mednafen crashes, it's very 
likely that a real Saturn will crash. SSF is the nex best 
emulator to use, but there are instances where it will run 
fine where as Mednafen and a real Saturn will crash. So
keep that in mind.

Crashes tend to happen during scripted scenes and scripted
map transitions. This is because every now and then the PS1
scripts use different codes than the Saturn version. However
the only way to catch this is to play the game and encounter
them. So that's where playtesting comes into play.

Asside from the odd crashing, the following issues are known:

	- Voice Audio is horribly out of sync during voiced dialogue.
	- The words "Ambushed" and "Your Initiative" in battle are
  	  out of alignment.
	- Battle Menu Icon text is not translated. This is actually
	  Graphical data that needs to be decompressed and edited.
	- Some Post Battle text is untranslated for similar reasons.
	- All but the first Map Screen are untranslated. The text
	  in these screens gets scaled by VDP1 which ended up looking
	  very poor. As a result I have not touched the others until
          I can figure out a better way to do this.
	- FMVs are untranslated. The format used for these is still
          unknown so these most likely wont be subtitled for a while.
	- Menu Selections are misalgined (Yes/No on Save Screen, etc.)

If you encounter a bug, please post it on the SegaXtreme thread
or post it on the SegaXtreme discord. When posting a bug please include
the following:
	
	- What exactly happened? (Game Crashed, Typo, Garbled Text, etc.)
	- Screenshots or Videos if possible.
	- What where you doing when it happened?
	- Where in the game where you when it happened?
	- A copy of your save file from your emulator.

----------------------------------------------------------
4. Change Log
----------------------------------------------------------

Disc 1 v0.05 (4/4/2019):
- Initial Beta Test Release