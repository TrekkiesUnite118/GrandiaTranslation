
				Sega Saturn Grandia
				   English Patch
				  April 21st, 2019	


This Patch will apply the official English Translation from the Sony PlayStation version of Grandia to the original Japanese Sega Saturn release. 

To follow the progress of this hack please be sure to pay attention to the thread at SegaXtreme.net:

https://segaxtreme.net/threads/translating-grandia.24330/

----------------------------------------------------------------
 C O N T E N T S
----------------------------------------------------------------

1. Source Image and Checksum Info
2. How to apply the patch
3. Known Issues
4. Notes about Running on Real Hardware
5. Debug Patch
6. Change Log

----------------------------------------------------------------
1. Source Image and Checksum Info
----------------------------------------------------------------

The Image used for this was a rip from my personal copy of the game. There's little information out there if there are other revisions of the game so be sure to check the checksums. I ripped my image file using ImgBurn and ripped as BIN/CUE format. After which I extracted the Data Track into an ISO file.

The Checksums Pre-Patch should be as follows for the ISO file:

MD5:     D1C273B9871A34E5D7A7168E30CDB421
CRC-32:  D4BF88BE
SHA-1 :  75146114330BA9A028974253FB2186A29241D631
SHA-256: 68FA1AED046E4F4F052E67A0A4FD56D4E3C661BF77A478854D96D9AD772CE543

Post Patch Checksums should be this:
 
MD5:     F3905125DAE6CF368C0CF4299E40A690
CRC-32:  E5B0010D
SHA-1 :  4645C4E9521F4508D0B8031BC61CFFB2C15D98DE
SHA-256: 5E59E1A45FF296CC6DEC899BDB31F67C848225D0B4D30B983D7A01DCFDFEFEB1

----------------------------------------------------------------
2. How to apply the patch
----------------------------------------------------------------

First you'll need a BIN/CUE rip of the game. I suggest using
ImgBurn to rip your personal disc in BIN/CUE format at the
Slowest possible speed.

You will then need to extract the data track from the BIN file. 
This will give you an ISO file that you can apply the patch to.
To do this you'll need additional software. The Software I used
was IsoBuster which can be found here:

https://www.isobuster.com/download.php

After installing and starting up IsoBuster, open the BIN/CUE image you created of your Grandia disc with it:

	1) Go to File > Open Image File
	2) Select the CUE file of your Grandia rip
	3) Click Open.

Next you'll need to extract the separate tracks:

	1) Right click on Session 1
	2) Select Extract Session 1 > Extract User Data

This will open a prompt asking where you want to save the data.
Navigate to the directory of your choosing and click OK.

This will give you Track 01 as an ISO and Track 02 as a Wav file. Rename these as follows:

	- GRANDIA.iso
	- GRANDIA.wav

You are now ready to apply the patch. The patch is in xdelta format, so you'll need to use a patching utility. I'd recommend using DeltaPatcher or DeltaPatcher Lite. Using DeltaPatcher apply the the patch as follows:

	1) Select GRANDIA.iso as your original file.
	2) Select the patch file included in this zip as the patch
	3) Click Appy Patch.

If that all went well you should be ready to go. The included CUE sheet is designed to be used with the extracted GRANDIA.wav file that IsoBuster extracted. If this does not work or you extracted the files under different names, you can use the SegaCueMaker to generate a new one.

----------------------------------------------------------------
3. Known Issues
----------------------------------------------------------------

This is still a very early release, so it is advised that 
you play this in an emulator as crashes are likely to occur.
The preferred Emulator is Mednafen as it seems to behave the
closest to the real deal. If Mednafen crashes, it's very 
likely that a real Saturn will crash. SSF is the next best 
emulator to use, but there are instances where it will run 
fine where as Mednafen and a real Saturn will crash. So
keep that in mind.

Crashes tend to happen during scripted scenes and scripted
map transitions. This is because every now and then the PS1
scripts use different codes than the Saturn version. However
the only way to catch this is to play the game and encounter
them. So that's where playtesting comes into play.

Aside from the odd crashing, the following issues are known:

	- Voice Audio is horribly out of sync during voiced 	 	  	  dialogue.
	- The words "Ambushed" and "Your Initiative" in battle are
  	  out of alignment.
	- Battle Menu Icon text is not translated. This is 	  	  	  actually Graphical data that needs to be decompressed 	 	  and edited.
	- Some Post Battle text is untranslated for similar 	 	  	  reasons.
	- All but the first Map Screen are untranslated. The text
	  in these screens gets scaled by VDP1 which ended up 	  	  looking very poor. As a result I have not touched the 	 	  others until I can figure out a better way to do this.
	- FMVs are untranslated. The format used for these is 	  	  still unknown so these most likely wont be subtitled for 	  a while.
	- Menu Selections are misaligned (Yes/No on Save Screen, 	  	  etc.)

If you encounter a bug, please post it on the SegaXtreme thread
or post it on the SegaXtreme discord. When posting a bug please include the following:
	
	- What exactly happened? (Game Crashed, Typo, Garbled 	  	  Text, etc.)
	- Screenshots or Videos if possible.
	- What where you doing when it happened?
	- Where in the game where you when it happened?
	- A copy of your save file from your emulator.

----------------------------------------------------------------
4. Notes about Running on Real Hardware
----------------------------------------------------------------

The patch right now is still in a very early state. Crashes are very likely to still happen so to avoid making coasters it's advised that you stick to emulation for now.

That said, the patch does at least work on real hardware so there's nothing stopping you from burning a disc if you want to. However the following things should be taken into account.

	1) Grandia is VERY picky about the Burn Speed used and the
	   quality of the media you use. The cheap Verbatims or 	  	   Memorex CD-Rs you buy at Best Buy will most likely not 	   	   cut it. You'll need to shell out for some JVC Taiyo 	  	   Yudens.

	2) Grandia does NOT play nice with 50Hz. So PAL users will 	   need a 60Hz switch installed most likely.

The reasoning for this comes down to two things. First Grandia uses a custom Video Codec. So if the burn isn't up to snuff you're going to get garbled audio and stuttering FMVs at best, if not a complete hang.

The other reason is that Grandia relies heavily on streaming data off the disc constantly for sounds, as well as doing lots of redundant reads and loads from the disc. If the burn isn't good, the game is going to be unstable.

----------------------------------------------------------------
5. Debug Patch
----------------------------------------------------------------

For people running on real hardware I've included a Debug Mode patch. This will put the game into Debug Mode which can be useful in giving me as much information as possible when the game crashes.

To use it, simply apply the patch using delta-patcher to an original unpatched rip of the game using the same instructions for the normal patch. Information on how this mode works and how to use it can be found at The Cutting Room Floor here:

https://tcrf.net/Grandia_(Sega_Saturn)

The two screens that are the most helpful are the Scenario Flag Screen and the Map Status Screen. If you encounter a crash or bug, do the following:

	1) Get a save file as close to the issue as possible.
	2) Boot up said save file using the Debug Disc.
	3) Take a screenshot of the Map Status Screen and the 		Scenario Flag screen.
	4) Include those two screenshots with your bug report on 		SegaXtreme

----------------------------------------------------------------
6. Change Log
----------------------------------------------------------------

Disc 1 v0.05 (4/4/2019):
- Initial Beta Test Release

Disc 1 v0.051 (4/4/2019):
- Fixed Patching Process

Disc 1 v0.052 (4/6/2019):
- Fixed Bug which had the game crashing at Parm.

Disc 1 v0.53 (4/15/2019):
- Remaining untranslated text in the Save/Load screen is now translated.
- Voice Audio for Intro scene with Mullen, Baal, and Leen should now be in sync with the text.
- Fixed a bug that a was happening when you meet Gadwin and the Boss Battle wasn't starting.
- Included a debug mode patch for real hardware users.
- Corrected an oops in my version numbering :P

Disc 1 v0.54 (4/21/2019):
- Fixed a crash that was happening at the boss in Typhoon Tower
- Voice Audio has been resynchronized for the following cutscenes:
    - Justin's Introduction
    - Meeting Justin's Mom.

